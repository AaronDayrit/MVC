﻿using System;
namespace Final_Proj.Models
{
	public class CompareLaptops
	{
		public string? Input1 { get; set; }
        public string? Input2 { get; set; }

        public Laptop Laptop1 { get; set; }
		public Laptop Laptop2 { get; set; }
	}
}


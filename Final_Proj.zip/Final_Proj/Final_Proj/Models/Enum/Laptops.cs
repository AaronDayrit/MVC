﻿using System;
namespace Final_Proj.Models.Enum
{
	public enum Laptops
	{
        /*
		    Laptop lenovo1 = new Laptop("ThinkBook-15", lenovo, 1513.99, 2021);
            Laptop lenovo2 = new Laptop("Ideapad", lenovo, 229.99, 2020);
            Laptop dell1 = new Laptop("Latitude 5290", dell, 9.99, 2011);
            Laptop dell2 = new Laptop("Inspiron 15 3000", dell, 429.99, 2022);
            Laptop acer1 = new Laptop("Nitro 5", acer, 799.99, 2022);
		 */
        

    }
}


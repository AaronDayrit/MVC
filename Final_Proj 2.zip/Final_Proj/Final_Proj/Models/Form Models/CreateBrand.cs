﻿using System;
namespace Final_Proj.Models
{
	public class CreateBrand
	{
        public string Name { get; set; }
        public Brand Result { get; set; }
    }
}


